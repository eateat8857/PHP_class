<?php ob_start();?>
<?php
session_start();
if($_SESSION["login"]=="No"){

}else{
    header("Location:error.php");
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>
           
        </title>
    </head>
    <body text="000000" bgcolor="#987669">
       登入失敗<br>
       網頁將在五秒後跳至登入頁面或<br>
       <a href="index.php">點選這裡</a>
       <?php
       header("Refresh:5;url=index.php")
       
       ?>
    </body>
</html>
<?php ob_flush();?>