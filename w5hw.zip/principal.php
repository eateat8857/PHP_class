<?php
session_start();
if($_SESSION["role"]=="principal"){
}else{
    header("Location:error.php");
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        
        <title>
           校長頁面
        </title>
    </head>
    <body text="000000" bgcolor="#BF8F8B">
    <h1>
        歡迎來到校長頁面!
        </h1>
        <br>
        <h2>
                <p>
                <IMG SRC="hw/teacher_student/principal.jpg" width="50%" border="5"></IMG><br/>
                <font size=3 face="微軟正黑">
                </p>
                <p>

                作為這所學校的校長，我對於學校的未來充滿著熱情和信心。我們的目標是提供一個優質的教育環境，讓每個學生都能夠實現他們的潛力和追求自己的夢想。<br/>

                我們的教學團隊是由一群教育專業人士組成，他們都擁有豐富的教學經驗和專業知識。我們的課程旨在培養學生的學術能力、創造力、社交技能和領導才能，並且提供學生豐富的課外活動和社會服務機會。<br/>

                我們致力於建立一個安全、友善和支持性的學習環境，讓學生能夠發揮自己的潛力和獲得成功。我們的學校是一個多元化和包容性的社區，我們歡迎各種文化和背景的學生。<br/>

                我們的校訓是“知識、尊重、責任和奉獻”，我們希望每個學生都能夠具備這些核心價值觀。我們相信這些價值觀將幫助學生們成為更好的人，更好的公民和更好的領袖。<br/>

                感謝您對我們學校的關注。如果您對我們的學校有任何疑問或者興趣，歡迎隨時聯繫我們！<br/>



 <br/>
                </p>
                </font>
        </h2>
        <br/>
        <a href="teacher.php">老師頁面</a>
        <a href="logout.php">Logout</a>

    </body>
</html>