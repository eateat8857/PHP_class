<?php
session_start();
if($_SESSION["role"]=="student"){
}else if($_SESSION["role"]=="teacher"){

}else{
    header("Location:error.php");
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        
        <title>
           學生頁面
        </title>
    </head>
    <body text="000000" bgcolor="#CAB8B2">
    <h1>
        歡迎來到學生頁面!
        </h1>
        <br>
        <h2>
                <p>
                <IMG SRC="hw/teacher_student/student.jpg" width="50%" border="5"></IMG><br/>
                <font size=3 face="微軟正黑">
                </p>
                <p>

                我們是一群充滿活力和熱情的學生，來自不同的年級和背景。我們在這裡分享我們的學習經驗、成就和興趣愛好，希望能夠與你建立更多的交流和互動。<br/>

                在我們的學校，我們有一個充滿活力和多元化的學生社區。我們在課堂上學習各種學科知識，同時也在學校的課外活動中發展自己的興趣愛好和技能。我們有各種各樣的學生俱樂部和組織，例如音樂、運動、科技和社區服務等等。<br/>

                我們相信，每個學生都有自己獨特的天賦和才能，我們鼓勵學生發揮自己的創造力和想象力，並且積極參與學校和社區的活動和項目。<br/>

                在我們的學生網頁上，你可以看到我們的成就和活動照片，也可以了解我們的學習和生活經驗。如果你是一位新學生，我們非常歡迎你加入我們的學生社區，和我們一起創造美好的未來！<br/>

                感謝您訪問我們的網頁，如果您有任何問題或意見，歡迎與我們聯繫！<br/>
                <br/>
                </p>
                </font>
        </h2>
        <br>

        <a href="logout.php">Logout</a>

    </body>
</html>
