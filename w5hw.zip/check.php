<?php
session_start();

$account=$_POST["id"];
$pwd=$_POST["pwd"];

if(($account=="teacher")&&($pwd=="123")){
    $_SESSION["role"]="teacher";
    header ("Location:teacher.php");
}else if(($account=="principal")&&($pwd=="456")){
    $_SESSION["role"]="principal";
    header ("Location:principal.php");
}else if(($account=="student")&&($pwd=="789")){
    $_SESSION["role"]="student";
    header ("Location:student.php");
}else{
        $_SESSION["login"]="No";
        header ("Location:fail.php");
}
?>
