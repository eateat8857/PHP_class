<html>
    <head>
        <meta charset="UTF-8">
        
        <title>
            登入頁面
        </title>
    </head>
    <body text="000000" bgcolor="#8A856B">
        <form method="post" action="check.php ">
            請輸入帳號:<input type="text" name="id"><br/>
            請輸入密碼:<input type="text" name="pwd"><br/>
            
            <input type="submit"><input type="reset">

        </form>
    </body>
</html>