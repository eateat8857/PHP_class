<?php
session_start();
if($_SESSION["role"]=="teacher"){
}else if($_SESSION["role"]=="principal"){

}else{
    header("Location:error.php");
}
?>

<html>
    <head>
        <meta charset="UTF-8">
        
        <title>
           老師頁面
        </title>
    </head>
    <body text="000000" bgcolor="#9496A3">
       <h1>
        歡迎來到老師頁面!
        </h1>
        <br>
        <h2>
                <p>
                <IMG SRC="hw/teacher_student/teacher.jpg" width="50%" border="5"></IMG><br/>
                <font size=3 face="微軟正黑">
                </p>
                <p>
                我是一位教育工作者，對於教育事業充滿熱情和經驗。<br/>

                教育是一個非常重要的領域，它能夠影響學生的一生。我的教學風格是以學生為中心，鼓勵學生發揮自己的創造力和想象力，幫助他們學習和發展出色的技能。<br/>

                我的課程包括各種主題和領域，從語言學習到科學和社會科學。我喜歡使用互動式教學方法，例如遊戲、小組討論和實驗，以幫助學生更好地理解和掌握課程內容。<br/>

                我相信每個學生都有獨特的學習風格和需求，因此我會盡力提供個性化的教學，以幫助學生充分發揮他們的潛力。<br/>

                謝謝您來到我的頁面，如果您對我的課程有興趣，歡迎聯繫我進一步了解詳情！  <br/>
                </p>
                </font>
        </h2>
        <a href="student.php">學生頁面</a>
        <a href="logout.php">Logout</a>

    </body>
</html>